% Verbitsky 2017 model V6N
%artificial periodic forcing
%reproduces Figs 7 and 9 
%Verbitsky, M. Y., Crucifix, M., & Volobuev, D. M. A Theory of Pleistocene Glacial Rhythmicity.
clearvars;
close all;
%parameters are described in the paper
% Fig. 7: e=0.07, 0.082, 0.11
% Fig. 9: alpha=0, k=0, e=0.045;
% FS=e*(1.*sin(2.*pi*t/23.)+0.*sin(2.*pi*t/41.)); - should be changed in
% Clim_Syst_V6
d=1.;%dzeta,10^-3/2 m^1/2
a=0.065;%km/kyr
c=0.042; %km/kyr/C
S0=12.;%10^6 KM2
alpha=2.0;%0
b=2.;%deg.C/10^6 km^2
g1=0.;%degC/kyr;
g2=0.21;%degC/10^6km2/kyr
g3=0.3;%kyr^-1
%_______________________
e=0.082;%0.07;0.11;    0.045;  %%scaling for FS
k=0.005;%0 ablation
tmin=4000;
tmax=5000;%kyr 
%____________________________
b91 = load('orbit91.txt');
I_65B =  [-b91(:,1) flipud(b91(:,6))];%6th column mid-Jul I for 65N, 7th colomn mid-Jan I for 65S 
I_65=I_65B; I_65(:,2) = (I_65B(:,2)-mean(I_65B(:,2)))/std(I_65B(:,2));
xlabel('kyr')
%%%%%%%%%%%%
Y0 = [10. 0. 2.];
[t,Y] = ode45(@(t,Y) Clim_Syst_V6(t,Y,g1,g2,g3,b,alpha,c,a,d,S0,e,k),(tmin:.1:tmax), Y0);
%Amplitude Fourier spectrum for ice V
FF=fft(Y(:,1).^(5/4));P2 = abs(FF/length(Y));P1 = P2(1:floor(length(Y)/2)+1);P1(2:end-1) = 2*P1(2:end-1);f = 10*(0:floor(length(Y)/2))/length(Y);
figure(1);plot(1./f,P1);xlabel('Period,kYr');ylabel('Amplitude');xlim([0 500])
DY=[];
for j=1:length(t),
dY=Clim_Syst_V6(t(j),Y(j,:),g1,g2,g3,b,alpha,c,a,d,S0,e,k);
DY=[DY dY];
end

figure(2);plot(t,DY');legend('dS/dt','d\theta/dt','d\omega/dt')
figure(3);subplot(221); plot(t,Y(:,1),'-k.');ylabel('S');xlabel('t')
subplot(222);plot(t,Y(:,2),'-g.');ylabel('T');xlabel('t')
subplot(223);plot(t,Y(:,3),'-b.');ylabel('\omega');xlabel('t')
subplot(224);plot(Y(:,1),Y(:,2));xlabel('S');ylabel('T')
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
figure(4);subplot(411);plot(I_65(:,1),I_65(:,2))
xlim([tmin tmax])
ylabel('I_6_5,W/m^2')
subplot(412); plot(t,Y(:,1),'-k.');ylabel('S');xlabel('t')
subplot(413);plot(t,Y(:,2),'-g.');ylabel('T');xlabel('t')
subplot(414);plot(t,Y(:,3),'-b.');ylabel('\omega');xlabel('t')
%______________________________________________________
LR04 = load('LR04.txt'); % LR04
figure(8)
subplot(211);plot(-LR04(:,1),LR04(:,2),'-b^','MarkerSize',2)
xlim([-1000 0])
ylabel('LR04')
subplot(212);plot(t-5000,(Y(:,1)).^(4/4),'-k.','MarkerSize',2)
ylabel('S')
SS=interp1(t-5000,Y(:,1),-LR04(1:801,1));
corrcoef(SS,LR04(1:801,2))
xlim([-1000 0])

load ELD.txt
%ELD=xlsread('Eld1221294_TABLES.xlsx','TABLE S1','M6:P1723');
%save('ELD.txt','ELD','-ascii')
%E=load('EDC3DEUTTemp2007MV.txt');
figure(9);
subplot(211);plot(-ELD(:,1),ELD(:,2),'-b^','MarkerSize',2)
xlim([-1000 0])
subplot(212);plot(t-5000,(Y(:,3)),'-k.','MarkerSize',2)
%%%%%%%%%%%%%%Fourier spectra for insolation
FF=fft(I_65B(:,2));P2 = abs(FF/length(I_65B));P1 = P2(1:floor(length(I_65B)/2)+1);P1(2:end-1) = 2*P1(2:end-1);f = 1*(0:floor(length(I_65B)/2))/length(I_65B);
figure(10);plot(1./f,P1);xlabel('Period,kYr');ylabel('Amplitude');xlim([0 500]);title('Fs')
%%%%%%%%%%%%%%Fourier spectra for LR04 and ELD
LL=interp1(-LR04(1:1000,1),LR04(1:1000,2),t-5000);
FF=fft(LL);P2 = abs(FF/length(LL));P1 = P2(1:floor(length(LL)/2)+1);P1(2:end-1) = 2*P1(2:end-1);f = 10*(0:floor(length(LL)/2))/length(LL);
figure(12);plot(1./f,P1);xlabel('Period,kYr');ylabel('Amplitude');xlim([0 500]);title('LR04')
%%%%%%%%%%%%%% Eld
ELD(diff(ELD(:,1))==0,1)=ELD(diff(ELD(:,1))==0,1)+0.01;
EL=interp1(-flipud(ELD(~isnan(ELD(:,2)),1)),flipud(ELD(~isnan(ELD(:,2)),2)),t(1:end-70)-5000);
FF=fft(EL);P2 = abs(FF/length(EL));P1 = P2(1:floor(length(EL)/2)+1);P1(2:end-1) = 2*P1(2:end-1);f = 10*(0:floor(length(EL)/2))/length(EL);
figure(13);plot(1./f,P1);xlabel('Period,kYr');ylabel('Amplitude');xlim([0 500]);title('^1^8O ELD')
%%%%%%%%%%%%%% omega
FF=fft(Y(:,3));P2 = abs(FF/length(Y));P1 = P2(1:floor(length(Y)/2)+1);P1(2:end-1) = 2*P1(2:end-1);f = 10*(0:floor(length(Y)/2))/length(Y);
figure(14);plot(1./f,P1);title('\omega');xlabel('Period,kYr');ylabel('Amplitude');xlim([0 500])
