function dY = Clim_Syst_V6(t,Y,FS,g1,g2,g3,b,alpha,c,a,d,S0,e,k)
FS = e*interp1(FS(:,1),FS(:,2),t);
dY(1) = (a-c*Y(2)-FS-k*Y(3))*4*(Y(1)^(3/4))/5/d;
if Y(1)+dY(1)<0.1; dY(1)=0;end % non-negative ice area
dY(2) = (a-FS-k*Y(3))*(Y(1)^(-1/4))*(alpha*Y(3)+b*(Y(1)-S0)-Y(2))/d;
dY(3) = g1-g2*(Y(1)-S0)-g3*Y(3);
dY = dY(:);