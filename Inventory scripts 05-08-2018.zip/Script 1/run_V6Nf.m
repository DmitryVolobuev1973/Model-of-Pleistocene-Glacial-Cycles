% Verbitsky 2017 model V6N
%Verbitsky, M. Y., Crucifix, M., & Volobuev, D. M. A Theory of Pleistocene Glacial Rhythmicity.
%Script for Late Pleistocene modeling
%Parameters are described in the paper
clearvars;
close all;
%default parameters are for Figs. 3, 4, 5 (low left, low right), 6;
%please use following values for Figs.2,8,10-11 
%Fig. 2 left:  g2=0.2, g3=0.25, e=0.
%Fig. 2 right: g2=0.2, g3=0.25, e=0.01
%Fig. 8: alpha=0, k=0, e=0.03
%Fig. 10: alpha=0, k=0, e=0.11, S0=2, Y0 = [3.5 0. 2.]
%Fig. 11: b=1.57
%dzeta,10^-3/2 m^1/2 %km/kyr  %km/kyr/C  %10^6 KM2         %deg.C/10^6 km^2
d=1.;               a=0.065;  c=0.042;   S0=12.; alpha=2.0; b=2.;
%Fig.8: d=1.;               a=0.065;  c=0.042;   S0=12.; alpha=0; b=2.;
%Fig.10: d=1.;               a=0.065;  c=0.042;   S0=2.; alpha=0.0; b=2.;

%degC/kyr; %degC/10^6km2/kyr  %kyr^-1 scaling FS %ablation
g1=0.;     g2=0.21;          g3=0.3;   e=0.11;  k=0.005;
%Fig.8: g1=0.;     g2=0.21;          g3=0.3;   e=0.03;  k=0.00;
%Fig.10: g1=0.;     g2=0.21;          g3=0.3;   e=0.11;  k=0.00;
Y0 = [10. 0. 2.];%initial conditions 
%Fig.10: Y0 = [3.5 0. 2.];%initial conditions 
tmin=4000;%model time starts from 0 (5000 kyr BP) to present, so Late Pleistocene (1000-0)kyr BP is (4000-5000) model time
tmax=5000;%kyr 
%____Insolation by Berger, A. and Loutre, M. F.: Insolation values for the climate of the last 10 million years, Quaternary Science Reviews, 10(4), 297-317, 1991
b91 = load('orbit91.txt');
I_65B =  [-b91(:,1) flipud(b91(:,6))];%6th column mid-Jul I for 65N, 7th colomn mid-Jan I for 65S 
I_65=I_65B; I_65(:,2) = (I_65B(:,2)-mean(I_65B(:,2)))/std(I_65B(:,2));
xlabel('kyr')
%%%%%%%%%%%%_Integration
[t,Y] = ode45(@(t,Y) Clim_Syst_V6(t,Y,I_65,g1,g2,g3,b,alpha,c,a,d,S0,e,k),(tmin:.1:tmax), Y0);
%Amplitude Fourier spectrum for ice V
FF=fft(Y(:,1).^(5/4));P2 = abs(FF/length(Y));P1 = P2(1:floor(length(Y)/2)+1);P1(2:end-1) = 2*P1(2:end-1);f = 10*(0:floor(length(Y)/2))/length(Y);
figure(1);plot(1./f,P1);xlabel('Period,kYr');ylabel('Amplitude');xlim([0 500])
%%%%%%_Calculation od differentials
DY=[];
for j=1:length(t),
dY=Clim_Syst_V6(t(j),Y(j,:),I_65,g1,g2,g3,b,alpha,c,a,d,S0,e,k);
DY=[DY dY];
end

figure(2);plot(t,DY');legend('dS/dt','d\theta/dt','d\omega/dt')
figure(3);subplot(221); plot(t,Y(:,1),'-k.');ylabel('S');xlabel('t')
subplot(222);plot(t,Y(:,2),'-g.');ylabel('T');xlabel('t')
subplot(223);plot(t,Y(:,3),'-b.');ylabel('\omega');xlabel('t')
subplot(224);plot(Y(:,1),Y(:,2));xlabel('S');ylabel('T')
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
figure(4);subplot(411);plot(I_65(:,1),I_65(:,2))
xlim([tmin tmax])
ylabel('I_6_5,W/m^2')
subplot(412); plot(t,Y(:,1),'-k.');ylabel('S');xlabel('t')
subplot(413);plot(t,Y(:,2),'-g.');ylabel('T');xlabel('t')
subplot(414);plot(t,Y(:,3),'-b.');ylabel('\omega');xlabel('t')
%______________________________________________________
LR04 = load('LR04.txt'); % LR04
figure(8)
subplot(211);plot(-LR04(:,1),LR04(:,2),'-b^','MarkerSize',2)
ylabel('LR04')
xlim([-1000 0])
subplot(212);plot(t-5000,(Y(:,1)).^(4/4),'-k.','MarkerSize',2)
ylabel('S')
SS=interp1(t-5000,Y(:,1),-LR04(1:801,1));
corrcoef(SS,LR04(1:801,2))
xlim([-1000 0])
load ELD.txt
figure(9);
subplot(211);plot(-ELD(:,1),ELD(:,2),'-b^','MarkerSize',2)
xlim([-1000 0])
ylabel('ELD SST')
subplot(212);plot(t-5000,(Y(:,3)),'-k.','MarkerSize',2)
ylabel('\omega')
%%%%%%%%%%%%%%Fourier spectra for insolation
FF=fft(I_65B(:,2));P2 = abs(FF/length(I_65B));P1 = P2(1:floor(length(I_65B)/2)+1);P1(2:end-1) = 2*P1(2:end-1);f = 1*(0:floor(length(I_65B)/2))/length(I_65B);
figure(10);plot(1./f,P1);xlabel('Period,kYr');ylabel('Amplitude');xlim([0 500]);title('Fs')
LL=interp1(-LR04(1:1000,1),LR04(1:1000,2),t-5000);
FF=fft(LL);P2 = abs(FF/length(LL));P1 = P2(1:floor(length(LL)/2)+1);P1(2:end-1) = 2*P1(2:end-1);f = 10*(0:floor(length(LL)/2))/length(LL);
figure(12);plot(1./f,P1);xlabel('Period,kYr');ylabel('Amplitude');xlim([0 500]);title('LR04')
%%%%%%%%%%%%%% Eld
ELD(diff(ELD(:,1))==0,1)=ELD(diff(ELD(:,1))==0,1)+0.01;
EL=interp1(-flipud(ELD(~isnan(ELD(:,2)),1)),flipud(ELD(~isnan(ELD(:,2)),2)),t(1:end-70)-5000);
FF=fft(EL);P2 = abs(FF/length(EL));P1 = P2(1:floor(length(EL)/2)+1);P1(2:end-1) = 2*P1(2:end-1);f = 10*(0:floor(length(EL)/2))/length(EL);
figure(13);plot(1./f,P1);xlabel('Period,kYr');ylabel('Amplitude');xlim([0 500]);title('^1^8O ELD')
%%%%%%%%%%%%%% omega
FF=fft(Y(:,3));P2 = abs(FF/length(Y));P1 = P2(1:floor(length(Y)/2)+1);P1(2:end-1) = 2*P1(2:end-1);f = 10*(0:floor(length(Y)/2))/length(Y);
figure(14);plot(1./f,P1);title('\omega');xlabel('Period,kYr');ylabel('Amplitude');xlim([0 500])
